# VozOculta 🎙️
Plataforma de relatos anónimos en audio.

Escucha historias impactantes contadas por personas reales, sin revelar su identidad.

## Cómo usar
Abre `index.html` en tu navegador. Haz clic en “Explora historias” para escuchar.

## Próximamente
- Subida de audios desde el navegador
- Filtros por categoría o emoción
- Conversión de texto a voz

## Autor
Creado por [Tu Nombre o Alias]
